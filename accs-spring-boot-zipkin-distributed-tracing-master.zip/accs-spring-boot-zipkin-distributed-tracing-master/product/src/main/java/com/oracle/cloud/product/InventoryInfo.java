package com.oracle.cloud.product;

public class InventoryInfo {
    private int inventory;
    private String node;

    public InventoryInfo() {
    }


    public int getInventory() {
        return inventory;
    }
 
    public String getNode() {
        return node;
    }
 

}
