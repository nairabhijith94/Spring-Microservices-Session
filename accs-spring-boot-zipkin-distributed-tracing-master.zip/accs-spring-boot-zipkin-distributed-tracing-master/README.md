## Distributed tracing for microservices on Oracle Cloud with Spring Cloud Sleuth and Zipkin

Details in the blog post - https://medium.com/oracledevs/distributed-tracing-for-microservices-on-oracle-cloud-with-spring-cloud-sleuth-and-zipkin-b67158ebb34a

![](https://cdn-images-1.medium.com/max/1000/1*KHeAnct847lqe3WvQ9sAEA.jpeg)
