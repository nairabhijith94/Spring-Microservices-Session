package com.edu.feesms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeesmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeesmsApplication.class, args);
	}

}
